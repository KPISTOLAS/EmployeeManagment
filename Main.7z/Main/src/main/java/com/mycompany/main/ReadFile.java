package com.mycompany.main;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;



public class ReadFile {

    private List<String> lines;

    public ReadFile(String fileReader) throws IOException {
        lines = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileReader))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
        }
    }

    public int getTotalSalary() {
        if (lines.size() >= 5) {
            return Integer.parseInt(lines.get(3)); // Fifth line (index 4) in the list
        } else {
            return (Integer) null; // File has less than 5 lines
        }
    }

}
