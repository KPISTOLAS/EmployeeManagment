package com.mycompany.main;


public  class Employee {
    private String name;
    private String position;
    private String department;
    private int salary;
    private static int Id = -1;
    public Employee(String name, String position, String department, int salary) {
        this.name = name;
        this.position = position;
        this.department = department;
        this.salary = salary;
        Id++;
    }
    public String getName() {
        return name;
    }
    public String getPosition() {
        return position;
    }
    public String getDepartment() {
        return department;
    }
    public int getSalary() {
        return salary;
    }
    public int getId() {
        return Id;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setPosition(String position) {
        this.position = position;
    }
    public void setDepartment(String department) {
        this.department = department;
    }
    public void setSalary(int salary) {
        this.salary = salary;
    }
    @Override
    public String toString() {
        return this.name+"\n"+this.position+"\n"+this.department+"\n"+this.salary+"\n"+this.Id;

    }
}
