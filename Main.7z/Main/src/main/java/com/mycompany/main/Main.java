package com.mycompany.main;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Main {

    static Employee E1;
    static ReadFile readFile;

    public static int TotalSalary(int numEmployees) throws FileNotFoundException, IOException {

        //code to get total salaries from employees
        int totalSalary = 0;
        String Fname;
        for (int i = 1; i <= numEmployees; i++) {
            Fname = i + ".txt";
            try {
                readFile = new ReadFile(Fname);
                totalSalary += readFile.getTotalSalary();
            } catch (IOException e) {
                // Handle file not found or other IO exceptions
                e.printStackTrace();
            }
        }
        return totalSalary;
    }

    public static void main(String[] args) throws IOException {
        // Create an empty list to store employees
        ArrayList<Object> arrayList = new ArrayList<>();

        
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
         java.awt.EventQueue.invokeLater(new Runnable() {
        public void run() {
            NewJFrame frame = new NewJFrame(); // Pass the list to the constructor
            frame.setVisible(true);
            frame.addWindowListener(new java.awt.event.WindowAdapter() {
                @Override
                public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                    List<Employee> list = frame.getEmployeeList();
                    System.out.println("Employee List (On Frame Close):");
                    for (Employee employee : list) {
                            // files the employee constructor from list 


                            E1 = new Employee("", "TestPosition", "TestDepartment", 0); E1 = new Employee(employee.getName(), employee.getPosition(), employee.getDepartment(), employee.getSalary());
       
                            String Fname = E1.getId() + ".txt";
        
                            try {
                                CreateFile createFile = new CreateFile(Fname, E1.toString());
                            } catch (IOException e) {
                               
                            }
                            
                            
                        }
                    }
                });
            }
        });
        /*//get total salary of all employees
         
         int totalSalary = TotalSalary(E1.getId());
        System.out.println("Total salary of all employees: " + totalSalary);*/

    }
}
