package com.mycompany.main;

import java.io.FileWriter;
import java.io.IOException;



public class CreateFile{
 public CreateFile(String filename, String input) throws IOException {
    FileWriter writer;
     writer = new FileWriter(filename);
    writer.write(input);
    writer.close();
  }
}